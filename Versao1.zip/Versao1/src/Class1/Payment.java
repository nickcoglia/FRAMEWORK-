package Class1;

public class Payment {
    private String payerName;
    private double amount;

    public Payment(String payerName, double amount) {
        this.payerName = payerName;
        this.amount = amount;
    }

    public void processPayment() {
        System.out.println("Pagamento de R$" + amount + " processado para " + payerName + ".");
    }

    public String getPayerName() {
        return payerName;
    }

    public double getAmount() {
        return amount;
    }
}