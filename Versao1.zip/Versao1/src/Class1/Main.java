package Class1;

public class Main {
    public static void main(String[] args) {
        Payment payment = new Payment("João Silva", 150.75);
        payment.processPayment();
    }
}
